"""
Author: PointNeXt

"""
from .cls_base import BaseCls, ClsHead